module.exports = {
  HOST: "extensiondb-1.czzb64wzgtnf.us-west-1.rds.amazonaws.com",
  USER: "admin",
  PASSWORD: "3202mdlp",
  DB: "innodb"
};
